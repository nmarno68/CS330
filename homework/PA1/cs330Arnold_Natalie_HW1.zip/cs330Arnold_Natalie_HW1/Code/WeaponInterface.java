public interface WeaponInterface {

    public void sounds();
}
