public class Axe implements WeaponInterface {

    public void sounds() {
        System.out.println("CHOP CHOP CHOP");
    }
}
