public class Pistol implements WeaponInterface {

    public void sounds() {
        System.out.println("BANG BANG BANG");
    }
}
