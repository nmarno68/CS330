public class Grunt extends Unit {

    public Grunt(){
        weapon = new Axe();
    }
}
