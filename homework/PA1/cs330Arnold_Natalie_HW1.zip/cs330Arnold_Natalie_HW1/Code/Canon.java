public class Canon implements WeaponInterface {

    public void sounds() {
        System.out.println("BOOM BOOM BOOM");
    }
}
