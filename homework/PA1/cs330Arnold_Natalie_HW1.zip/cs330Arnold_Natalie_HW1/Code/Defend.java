public class Defend implements OrderInterface {

    public void execute(){
        System.out.println("We're in a tank lol u mad");
    }
}
