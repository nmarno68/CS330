public interface OrderInterface {

    public void execute();
}
