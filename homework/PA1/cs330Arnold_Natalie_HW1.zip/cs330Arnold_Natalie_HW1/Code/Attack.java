public class Attack implements OrderInterface{

    public void execute() {
        System.out.println("Push Forward!");
    }
}
