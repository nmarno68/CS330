public class Flee implements OrderInterface {

    public void execute() {
        System.out.println("OH GOD NO RUN AWAY");
    }
}
