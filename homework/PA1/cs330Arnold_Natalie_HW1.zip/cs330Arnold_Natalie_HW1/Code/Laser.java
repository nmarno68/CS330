public class Laser implements WeaponInterface {

    public void sounds() {
        System.out.println("PEW PEW PEW");
    }
}
